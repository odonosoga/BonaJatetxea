<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /var/www/html/ErronkaTaldea3/BonaJatetxea/bona-web/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>