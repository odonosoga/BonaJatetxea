<?php echo e($slot); ?>

<?php /**PATH /var/www/html/ErronkaTaldea3/BonaJatetxea/bona-web/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>