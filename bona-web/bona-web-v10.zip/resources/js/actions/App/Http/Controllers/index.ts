import Auth from './Auth'
import ReservationController from './ReservationController'

const Controllers = {
    Auth: Object.assign(Auth, Auth),
    ReservationController: Object.assign(ReservationController, ReservationController),
}

export default Controllers