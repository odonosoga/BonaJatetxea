import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReservationController::index
* @see app/Http/Controllers/ReservationController.php:11
* @route '/erreserbak'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/erreserbak',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReservationController::index
* @see app/Http/Controllers/ReservationController.php:11
* @route '/erreserbak'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReservationController::index
* @see app/Http/Controllers/ReservationController.php:11
* @route '/erreserbak'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReservationController::index
* @see app/Http/Controllers/ReservationController.php:11
* @route '/erreserbak'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReservationController::index
* @see app/Http/Controllers/ReservationController.php:11
* @route '/erreserbak'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReservationController::index
* @see app/Http/Controllers/ReservationController.php:11
* @route '/erreserbak'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReservationController::index
* @see app/Http/Controllers/ReservationController.php:11
* @route '/erreserbak'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ReservationController::store
* @see app/Http/Controllers/ReservationController.php:22
* @route '/erreserbak/validate'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/erreserbak/validate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReservationController::store
* @see app/Http/Controllers/ReservationController.php:22
* @route '/erreserbak/validate'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReservationController::store
* @see app/Http/Controllers/ReservationController.php:22
* @route '/erreserbak/validate'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ReservationController::store
* @see app/Http/Controllers/ReservationController.php:22
* @route '/erreserbak/validate'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ReservationController::store
* @see app/Http/Controllers/ReservationController.php:22
* @route '/erreserbak/validate'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const ReservationController = { index, store }

export default ReservationController