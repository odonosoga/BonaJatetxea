import AuthenticatedSessionController from './AuthenticatedSessionController'
import RegisterController from './RegisterController'

const Auth = {
    AuthenticatedSessionController: Object.assign(AuthenticatedSessionController, AuthenticatedSessionController),
    RegisterController: Object.assign(RegisterController, RegisterController),
}

export default Auth