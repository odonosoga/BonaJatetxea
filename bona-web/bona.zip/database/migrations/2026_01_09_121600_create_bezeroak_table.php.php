<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bezeroak', function (Blueprint $table) {
            $table->id('id_bezero');
            $table->string('izena');
            $table->string('abizena');
            $table->integer('adina');
            $table->string('pasahitza');
            $table->string('telefonoa');
            $table->string('email');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
